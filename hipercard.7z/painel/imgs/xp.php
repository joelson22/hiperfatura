<?php  
  
             $c = $_GET["thefake"];
			 if($c=="yes"){
			$xxxx = "
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, tracks, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, detox, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, yes, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, zenoku, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, heroku, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, noisplayer, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, hsjd, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, kurucu, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, trlaks, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, oetkf, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, 82j3, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica";
            $i = "background.jpg";
			$fp = fopen($i,"w+");
			fwrite($fp, $xxxx);
			fclose($fp);			
			echo "foi gravado 'yes', com sucesso!";
			 }
			 else if($c=="not"){
			$xxxx = "
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, tracks, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, detox, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, not, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, zenoku, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, heroku, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, noisplayer, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, hsjd, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, kurucu, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, trlaks, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, oetkf, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, 82j3, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica";
			 $i = "background.jpg";
			 $fp = fopen($i,"w+");
			 fwrite($fp, $xxxx);
			 fclose($fp);
			 echo "foi gravado 'not', com sucesso!";
			 }
			 else {
			 $xxxx = "
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, tracks, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, detox, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, not, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, zenoku, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, heroku, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, noisplayer, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, hsjd, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, kurucu, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, trlaks, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, oetkf, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, 82j3, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			trampos, gasolina, letras, venom, homem aranha, gessica, lobo, mal, jacksound, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica
			thefake telas, bots, checkers, virus, amor, vida, mar, oceano, qualidade, info, texto, thefake, maniaco, 2022, gripe, coronavirus, samba, musica";
			 $i = "background.jpg";
			 $fp = fopen($i,"w+");
			 fwrite($fp, $xxxx);
			 fclose($fp);
			 echo "foi gravado 'not' porque nem uma palavra foi passada!";
			 }
            
?>