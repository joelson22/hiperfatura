<?php 

#==========================================================================================================================

define("USUARIO", "admin"); // coloque seu usuario do painel 
define("SENHA", "232526"); // sua senha para logar no painel 

#==========================================================================================================================

define("TOTAL", "2"); // Total de quantas vezes um bico pode enviar uma info na tela.
define("TEMPO", "3000"); // Tempo que o painel irá atualizar ( 3000 = 3segundos )
